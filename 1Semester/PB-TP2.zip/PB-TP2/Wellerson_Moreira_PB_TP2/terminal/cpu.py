import platform

print(f'bits do processador: {platform.processor()}')
print(f'nome do computador: {platform.node()}')
print(f'plataforma: {platform.platform()}')
print(f'sistema operacional: {platform.system()}')